// generate min and max no within given range including min and max no
import homePage from "./homePage";
import hotelSearchPage from "./hotelSearchPage";


export default class hotelDetailsPage{
    chooseRoom:any;
    fourStarRatingCheckbox:any;

    constructor() {
        this.chooseRoom = $(`/html//ul[@id='HotelSearchResults']/li[2]/div//button[.='Choose Room']`);
        this.fourStarRatingCheckbox = $(`li:nth-of-type(2) > .star-filter-label > .icon-checkmark`);
    }
  //set four star ratings filter
  setFourStarRatingHotels() {
    this.fourStarRatingCheckbox.click();
    browser.pause(3000);
}

randomNo(min, max) {
    return Math.floor(Math.random() * (max - min + 1) + min);
  }

// check room availability for a hotel filtered as per star rating
checkRoomAvailability() {
    
    this.chooseRoom.click();
    let availableRoomCount = $(`h3#hotel-rooms-count > strong`).getText().split(" ", 1);
    return availableRoomCount;
}
}