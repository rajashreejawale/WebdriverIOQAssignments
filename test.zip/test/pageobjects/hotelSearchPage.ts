import homePage from "./homePage";

export default class hotelSearchPage extends homePage {
    hotelTab:any; 
    destination:any;
    checkInDate:any;
    checkOutDate:any;
    adults:any;
    children:any;
    searchHotelsButton:any;
    hotelSearchResult:any;
    selectDestination: any;
    checkInDateCalender: any;
    checkoutDateCalender: any;
    //define selectors
  constructor() {
    super();
    this.hotelTab = $(`ul[role='tablist'] > li:nth-of-type(2) > button`);
    this.destination = $("/html//input[@id='inputDestination']");
    this.selectDestination = $(`ul[role='listbox']`);
   //this.checkInDate = $(`/html//input[@id='inputCheckInDate']`);
    this.checkInDate = $('//*[@id="inputCheckInDate_Label"]/parent::*/div/input[2]');
    this.checkInDateCalender =$("//a[@id='jd-10-08-20']");
    this.checkoutDateCalender =$('//*[@id="jd-10-15-20"]');
     // this.checkOutDate = $(`/html//input[@id='inputCheckOutDate`);
    // this.adults = $(`/html//select[@id='selectHotelNumberAdults']`);
    // this.children = $(`/html//select[@id='selectHotelNumberChildren']`);
    this.searchHotelsButton = $(`/html//button[@id='hotelSearchButton']`);
    //  this.hotelSearchResult = $(`//h1[@class='js-wayfinder-heading view-title']`);
    }
       
    open() {
        super.open();
        this.hotelTab.click();
        return browser;
    }

    setDestination(city:String){
        this.destination.setValue(city);
    }

    
    setCheckinDate(date:string){
        browser.pause(1000);
        this.checkInDate.click();
        browser.pause(1000);
        this.checkInDateCalender.click();
        browser.pause(1000);
            }

    setCheckoutDate(date:string) {
        browser.pause(1000);
        this.checkoutDateCalender.click();
        browser.pause(1000);
    }

    clickSearchHotelButton() {
        browser.pause(1000);
        this.searchHotelsButton.click();
        browser.pause(1000);
    }

}