// import homePage from '../pageobjects/homePage';
// import hotelSearchPage from '../pageobjects/hotelSearchPage';
// import hotelResultPage from '../pageobjects/hotelResultPage';
// import hotelDetailsPage from '../pageobjects/hotelDetailsPage';

// describe('Hotel search page tests', () => {
//     let HotelSearchPage;
//     let HotelResultPage;
//     let HotelDetailsPage;

//     before( () => {
//         browser.maximizeWindow();
//         HotelSearchPage = new hotelSearchPage();
//         HotelSearchPage.open();

//         browser.pause(5000);
//         HotelSearchPage.setDestination('Boston, MA');
//         HotelSearchPage.setCheckinDate();
//         HotelSearchPage.setCheckoutDate();
//         HotelSearchPage.clickSearchHotelButton();
//         browser.pause(3000);
//         HotelResultPage = new hotelResultPage();
//         HotelDetailsPage = new hotelDetailsPage();
//     })
    
  
    
// })