import hotelResultPage from '../pageobjects/hotelResultPage';

class pagination {

    static pageSize = 25;
    static maxPages = 9;
    // Calculate total pages of hotel result
    getHotelResultTotalPages() {
        return Math.ceil(this.getHotelResultCount() / 25);
    }

    pagination(totalPages: number, currentPage: number = 1, pageSize: number = 25, maxPages: number = 9) {

        //scroll the page and go to pagination
        totalPages = Math.ceil(this.getHotelResultCount() / 25);
        let startPage: number;
        let endPage: number

        if (totalPages < maxPages) { // total page less than max pages to show all pages
            startPage = 1;
            endPage = totalPages;
        } else {
            //total pages more than max pages then calculate start and end pages
            let maxPagesBeforeCurrentPage = Math.floor(maxPages/2);
            let maxPagesAfterCurrentPage = Math.ceil(maxPages/2) -1;
            if (currentPage <= maxPagesBeforeCurrentPage) {
                //current page near the start
                startPage = 1;
                endPage = maxPages;
            } else if( currentPage + maxPagesAfterCurrentPage >= totalPages ) {
                //current page near the end
                startPage =  totalPages - maxPages + 1;
                endPage = totalPages;
            } else{
                //current page somewhere in middle
                startPage = currentPage - maxPagesBeforeCurrentPage ;
                endPage = currentPage + maxPagesAfterCurrentPage;
            }

            // calculate start and end index of hotel result 
            let startIndex = (currentPage - 1 ) * pageSize;
            let endIndex = Math.min(startIndex + pageSize - 1, totalPages - 1);


        }

        }


    }

    //check if total pages >1  then show Next button
}