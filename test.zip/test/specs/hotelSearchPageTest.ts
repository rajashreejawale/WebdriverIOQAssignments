import homePage from '../pageobjects/homePage';
import hotelSearchPage from '../pageobjects/hotelSearchPage';
import hotelResultPage from  '../pageobjects/hotelResultPage';

describe('Hotel search page tests', () => {
    let HotelSearchPage;
    let HotelResultPage ;

    before(() => {
        browser.maximizeWindow();
        HotelSearchPage = new hotelSearchPage();
        HotelSearchPage.open();
        HotelResultPage = new hotelResultPage();

    })

    it('should search Hotels', () => {
        browser.pause(5000);
        HotelSearchPage.setDestination('Las Vegas, NV');
        HotelSearchPage.setCheckinDate();
        HotelSearchPage.setCheckoutDate();
        HotelSearchPage.clickSearchHotelButton();
        browser.pause(3000);
    });

    it('should Search result wayfinder information', () => {
        let str = HotelResultPage.getHotelWayfinderInfo();
        expect(str).toContain('Las Vegas, NV (LAS)');
    });

    it('should Search result hotel count', () => {
        let str = HotelResultPage.getHotelResultCount();
        expect(str).toBe(HotelResultPage.getHotelResultCount());
    });

    it('should Search result hotel location', () => {
        expect(HotelResultPage.gethotelLocationInResult()).toBe(true);
    });

    it('should Search result hotel name filter when hotel exists', () => {
        HotelResultPage.setHotelNameFilter('Four Seasons Hotel Las Vegas');
        HotelResultPage.selectAutolistedHotel();
      let hotelName = $(`.hotel-name-titleshow-guest-summary`);
      expect(hotelName.getText()).toContain('Four Seasons Hotel Las Vegas');
      HotelResultPage.clearHotelNameFilter();
      browser.pause(5000);   
    });

    // it('should Search result hotel name filter when hotel does not exists', () => {
    //     HotelResultPage.setHotelNameFilter('Tahiti Village');
    //     HotelResultPage.selectAutolistedHotel();
    //     expect(HotelResultPage.flashNoHotelFoundMsg()).toContain("We couldn’t find any hotels that match your filter selections. Your filter selections have been removed. View all hotels below.");  
    //     expect(HotelResultPage.getHotelNameFilter).toBeNull();
    //     browser.pause(3000);
    // });

    // it(' verify start rating checkbox', () => {
    //     let x= 4;
    //     HotelResultPage.setStartRating(x);
    //     HotelResultPage.starFilterHotelResult(x);
    //     expect( HotelResultPage.starRatingCheckBox).toBeChecked;
    //    // expect(HotelResultPage.getCheckBoxElement(x)).isSelected().equals(true);
    //     expect(HotelResultPage.starRatingResult).toContain(`${x} out of 5`);
    //     HotelResultPage.setStartRating(x);

    // })
    
    
    it('Verify 5 star rating hotels', () => {
        HotelResultPage.setFiveStarRatingHotels();
        let stars =$(`dd[title='5 out of 5 total stars']`);
        //expect(HotelResultPage.getCheckBoxElement(index)).isSelected()).equals(true);
        expect(stars.getText()).toContain('5 out of 5');
        HotelResultPage.setFiveStarRatingHotels();
        browser.pause(3000);
    });

    it('Verify 4 star rating hotels', () => {
        HotelResultPage.setFourStarRatingHotels();
        let stars =$(`dd[title='4 out of 5 total stars']`);
        expect(stars.getText()).toContain('4 out of 5');
        HotelResultPage.setFourStarRatingHotels();
        browser.pause(3000);
    });

    it('Verify 3 star rating hotels', () => {
        HotelResultPage.setThreeStarRatingHotels();
        let stars =$(`dd[title='3 out of 5 total stars']`);
        expect(stars.getText()).toContain('3 out of 5');
        HotelResultPage.setThreeStarRatingHotels();
        browser.pause(3000);
    });

    it('Verify 2 star rating hotels', () => {
        HotelResultPage.setTwoStarRatingHotels();
        let stars =$(`dd[title='2 out of 5 total stars']`);
        expect(stars.getText()).toContain('2 out of 5');
        HotelResultPage.setTwoStarRatingHotels();
        browser.pause(3000);
    });

    it('verify room availability of selected hotel', () => {
        let availableRoomCount = HotelResultPage.checkRoomAvailability();
        expect(parseInt(availableRoomCount)).toBeGreaterThan(1);
        let selectedHotelName = $(`/html//div[@id='HotelResultContent']/div[2]//span[@class='margin-right-1']`).getText();
        console.log("available room count is : "+availableRoomCount);
        console.log("Selected HotelName is : "+selectedHotelName);
        let stars =$(`//div[@class='hotel-details-star-rating-container']//*[local-name()='svg']`).getText();
        console.log('Star count is: '+stars);

    });
})












// Seperate Hotel Details PAge
//Optimize Star rating test test cases
// remove seletors from test file